import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/jason247g/Dawg/main/wizard_builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/jason247g/Dawg/main/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
